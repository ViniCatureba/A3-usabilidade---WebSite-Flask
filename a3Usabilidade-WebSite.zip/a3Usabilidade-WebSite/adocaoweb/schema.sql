CREATE TABLE amigos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome varchar(30),
    idade INTEGER,
    especie varchar(4),
    descricao varchar(150),
    imagem BLOB 
);