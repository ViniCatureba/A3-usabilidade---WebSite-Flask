from flask_mysqldb import MySQL
from flask import Flask,request, render_template, g, flash
import io
import base64
import PIL
from PIL import Image



UPLOAD_FOLDER = './upload'
ALLOWED_EXTENSIONS = {'png', 'jpeg'}
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config["TEMPLATES_AUTO_RELOAD"] = True


app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Vinivini14!'
app.config['MYSQL_DB'] = 'websiteamigos'
global myslq
mysql = MySQL(app)




@app.route("/")
def index():
    
    
    return render_template("index.html")


@app.route("/add", methods = ["POST",])
def insertIntoDB():
    cursor = mysql.connection.cursor()
    

    nome = request.form["nomeAnimal"]
    idade = request.form["idadeAnimal"]
    tipo = request.form["tipoAnimal"]
    telefone = request.form["telefonedono"]
    raca = request.form["racaamigo"]

    cursor.execute("""
        INSERT INTO amigos 
            (nome, idade, especie, telefone, raca )
        VALUES (%s, %s, %s, %s, %s) """,
        (nome, idade, tipo, telefone, raca)
    )

    mysql.connection.commit()
    cursor.close()
    return render_template("obrigadodoar.html")

@app.route("/done", methods = ["POST",])
def adotado():
    cursor = mysql.connection.cursor()
    idnum = request.form["idhidden"]
    cursor2 = mysql.connection.cursor()
    cursor2.execute("""
    select telefone from amigos where id = (%s) ;
    """,
    (idnum))
    cursor.execute("""
    DELETE FROM amigos WHERE id = (%s);
    
    """,
    (idnum)
    )
    resultid = cursor2.fetchall()

    mysql.connection.commit()
    cursor.close()
    return render_template("obrigado.html",resultid=resultid)

     

@app.route("/faq")
def faq():
    return render_template("faq.html")


@app.route("/adotar", methods = ['GET',])
def adotar():
    cursor = mysql.connection.cursor()
    
    cursor.execute("""
    SELECT id, nome, idade, especie, telefone, raca
    FROM amigos
    """)
    resultado = cursor.fetchall()
    

    mysql.connection.commit()
    
    

    cursor.close()
    return render_template("adotaranimais.html",
                resultado=resultado)








@app.route("/doaranimais")
def doaranimais():
    return render_template("doaranimais.html")



if __name__ == '__main__':
    app.debug = True
    app.run()
